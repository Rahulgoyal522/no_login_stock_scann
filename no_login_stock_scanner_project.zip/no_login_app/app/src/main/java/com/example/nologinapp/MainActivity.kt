package com.example.nologinapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.example.nologinapp.ui.theme.AppTheme
import com.example.nologinapp.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppNav() } }
    }
}

@Composable
private fun AppNav() {
    val nav = rememberNavController()
    Scaffold { pad ->
        NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen { nav.navigate("platform") } }
            composable("platform") { PlatformPickerScreen { nav.navigate("scan/$it") } }
            composable("scan/{platform}") { backStack -> ScanScreen(backStack.arguments?.getString("platform") ?: "Platform", nav) }
            composable("settings") { SettingsScreen() }
        }
    }
}
