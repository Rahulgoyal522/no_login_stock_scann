package com.example.nologinapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable fun HomeScreen(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(36.dp)); Text("Stock Scanner", style = MaterialTheme.typography.headlineMedium)
        Text("No-login edition", style = MaterialTheme.typography.titleMedium)
        Text("Choose a platform and scan product availability. Authentication/activation is intentionally not included.")
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Choose Platform") }
    }
}

@Composable fun PlatformPickerScreen(onPick: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Select platform", style = MaterialTheme.typography.headlineSmall)
        listOf("BigBasket", "Blinkit", "Swiggy Instamart").forEach { p ->
            OutlinedButton(onClick = { onPick(p) }, modifier = Modifier.fillMaxWidth()) { Text(p) }
        }
    }
}

@Composable fun ScanScreen(platform: String, nav: NavController) {
    var query by remember { mutableStateOf("") }
    var scanning by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(listOf<String>()) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(platform, style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { nav.navigate("home") }) { Text("Home") }
        }
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Product / SKU") })
        Button(onClick = { scanning = true; results = if (query.isBlank()) emptyList() else listOf("Demo result for $query", "No-login local result placeholder") }, modifier = Modifier.fillMaxWidth()) { Text(if (scanning) "Scan again" else "Start Scan") }
        if (results.isNotEmpty()) LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(results) { Text(it, modifier = Modifier.fillMaxWidth().padding(12.dp)) } }
        else Text("No results yet. Connect an authorized data source/API to make live scans work.")
    }
}

@Composable fun SettingsScreen() { Column(Modifier.fillMaxSize().padding(24.dp)) { Text("Settings", style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(12.dp)); Text("Authentication and activation are disabled in this project.") } }
