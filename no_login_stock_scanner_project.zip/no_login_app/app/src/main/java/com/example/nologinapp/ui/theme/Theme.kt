package com.example.nologinapp.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
@Composable fun AppTheme(content: @Composable () -> Unit) { MaterialTheme(content = content) }
